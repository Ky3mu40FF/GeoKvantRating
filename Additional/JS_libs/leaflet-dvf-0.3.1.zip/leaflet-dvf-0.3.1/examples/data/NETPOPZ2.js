var NLpopdens =[
	{
		"GEOZIP2NL": "10",
		"NAME": "10",
		"POPU": "635100",
		"AREA": "162.18",
		"Density": "3916.0192378838"
	},
	{
		"GEOZIP2NL": "11",
		"NAME": "11",
		"POPU": "263500",
		"AREA": "227.11",
		"Density": "1160.2307251993"
	},
	{
		"GEOZIP2NL": "12",
		"NAME": "12",
		"POPU": "165900",
		"AREA": "141.28",
		"Density": "1174.2638731597"
	},
	{
		"GEOZIP2NL": "13",
		"NAME": "13",
		"POPU": "131000",
		"AREA": "225.04",
		"Density": "582.1187344472"
	},
	{
		"GEOZIP2NL": "14",
		"NAME": "14",
		"POPU": "189500",
		"AREA": "316.83",
		"Density": "598.1125524729"
	},
	{
		"GEOZIP2NL": "15",
		"NAME": "15",
		"POPU": "152500",
		"AREA": "118.01",
		"Density": "1292.2633675112"
	},
	{
		"GEOZIP2NL": "16",
		"NAME": "16",
		"POPU": "164200",
		"AREA": "312.42",
		"Density": "525.5745470841"
	},
	{
		"GEOZIP2NL": "17",
		"NAME": "17",
		"POPU": "228900",
		"AREA": "872.92",
		"Density": "262.2233423452"
	},
	{
		"GEOZIP2NL": "18",
		"NAME": "18",
		"POPU": "142300",
		"AREA": "181.11",
		"Density": "785.7103417812"
	},
	{
		"GEOZIP2NL": "19",
		"NAME": "19",
		"POPU": "176200",
		"AREA": "188.10",
		"Density": "936.735778841"
	},
	{
		"GEOZIP2NL": "20",
		"NAME": "20",
		"POPU": "186900",
		"AREA": "96.60",
		"Density": "1934.7826086957"
	},
	{
		"GEOZIP2NL": "21",
		"NAME": "21",
		"POPU": "174800",
		"AREA": "225.61",
		"Density": "774.7883515802"
	},
	{
		"GEOZIP2NL": "22",
		"NAME": "22",
		"POPU": "292000",
		"AREA": "230.05",
		"Density": "1269.2892849381"
	},
	{
		"GEOZIP2NL": "23",
		"NAME": "23",
		"POPU": "201100",
		"AREA": "156.23",
		"Density": "1287.2047622096"
	},
	{
		"GEOZIP2NL": "24",
		"NAME": "24",
		"POPU": "119200",
		"AREA": "206.40",
		"Density": "577.519379845"
	},
	{
		"GEOZIP2NL": "25",
		"NAME": "25",
		"POPU": "444700",
		"AREA": "66.33",
		"Density": "6704.3570028645"
	},
	{
		"GEOZIP2NL": "26",
		"NAME": "26",
		"POPU": "235800",
		"AREA": "216.62",
		"Density": "1088.5421475395"
	},
	{
		"GEOZIP2NL": "27",
		"NAME": "27",
		"POPU": "157400",
		"AREA": "131.39",
		"Density": "1197.9602709491"
	},
	{
		"GEOZIP2NL": "28",
		"NAME": "28",
		"POPU": "118800",
		"AREA": "180.07",
		"Density": "659.7434331093"
	},
	{
		"GEOZIP2NL": "29",
		"NAME": "29",
		"POPU": "240500",
		"AREA": "274.43",
		"Density": "876.3619137849"
	},
	{
		"GEOZIP2NL": "30",
		"NAME": "30",
		"POPU": "544900",
		"AREA": "112.49",
		"Density": "4843.9861321006"
	},
	{
		"GEOZIP2NL": "31",
		"NAME": "31",
		"POPU": "265400",
		"AREA": "202.83",
		"Density": "1308.4849381255"
	},
	{
		"GEOZIP2NL": "32",
		"NAME": "32",
		"POPU": "271000",
		"AREA": "752.98",
		"Density": "359.9033174852"
	},
	{
		"GEOZIP2NL": "33",
		"NAME": "33",
		"POPU": "249300",
		"AREA": "189.53",
		"Density": "1315.3590460613"
	},
	{
		"GEOZIP2NL": "34",
		"NAME": "34",
		"POPU": "177600",
		"AREA": "349.50",
		"Density": "508.1545064378"
	},
	{
		"GEOZIP2NL": "35",
		"NAME": "35",
		"POPU": "233900",
		"AREA": "56.26",
		"Density": "4157.4831141131"
	},
	{
		"GEOZIP2NL": "36",
		"NAME": "36",
		"POPU": "94500",
		"AREA": "203.59",
		"Density": "464.1681811484"
	},
	{
		"GEOZIP2NL": "37",
		"NAME": "37",
		"POPU": "238000",
		"AREA": "415.71",
		"Density": "572.5144932766"
	},
	{
		"GEOZIP2NL": "38",
		"NAME": "38",
		"POPU": "266900",
		"AREA": "711.27",
		"Density": "375.2442813559"
	},
	{
		"GEOZIP2NL": "39",
		"NAME": "39",
		"POPU": "205500",
		"AREA": "403.90",
		"Density": "508.7893042832"
	},
	{
		"GEOZIP2NL": "40",
		"NAME": "40",
		"POPU": "68600",
		"AREA": "206.33",
		"Density": "332.4770997916"
	},
	{
		"GEOZIP2NL": "41",
		"NAME": "41",
		"POPU": "110100",
		"AREA": "353.37",
		"Density": "311.5714406996"
	},
	{
		"GEOZIP2NL": "42",
		"NAME": "42",
		"POPU": "103100",
		"AREA": "348.53",
		"Density": "295.8138467277"
	},
	{
		"GEOZIP2NL": "43",
		"NAME": "43",
		"POPU": "141100",
		"AREA": "457.72",
		"Density": "308.2670628332"
	},
	{
		"GEOZIP2NL": "44",
		"NAME": "44",
		"POPU": "90700",
		"AREA": "468.89",
		"Density": "193.4355605792"
	},
	{
		"GEOZIP2NL": "45",
		"NAME": "45",
		"POPU": "107400",
		"AREA": "742.60",
		"Density": "144.6269862645"
	},
	{
		"GEOZIP2NL": "46",
		"NAME": "46",
		"POPU": "122900",
		"AREA": "435.82",
		"Density": "281.9971547887"
	},
	{
		"GEOZIP2NL": "47",
		"NAME": "47",
		"POPU": "160500",
		"AREA": "440.24",
		"Density": "364.5738687988"
	},
	{
		"GEOZIP2NL": "48",
		"NAME": "48",
		"POPU": "221800",
		"AREA": "390.74",
		"Density": "567.640886523"
	},
	{
		"GEOZIP2NL": "49",
		"NAME": "49",
		"POPU": "86200",
		"AREA": "150.31",
		"Density": "573.4814716253"
	},
	{
		"GEOZIP2NL": "50",
		"NAME": "50",
		"POPU": "254300",
		"AREA": "409.01",
		"Density": "621.7451896042"
	},
	{
		"GEOZIP2NL": "51",
		"NAME": "51",
		"POPU": "144000",
		"AREA": "389.61",
		"Density": "369.6003696004"
	},
	{
		"GEOZIP2NL": "52",
		"NAME": "52",
		"POPU": "230200",
		"AREA": "333.43",
		"Density": "690.3997840626"
	},
	{
		"GEOZIP2NL": "53",
		"NAME": "53",
		"POPU": "167300",
		"AREA": "455.51",
		"Density": "367.2806305021"
	},
	{
		"GEOZIP2NL": "54",
		"NAME": "54",
		"POPU": "193800",
		"AREA": "593.47",
		"Density": "326.5539959897"
	},
	{
		"GEOZIP2NL": "55",
		"NAME": "55",
		"POPU": "161200",
		"AREA": "481.35",
		"Density": "334.891451127"
	},
	{
		"GEOZIP2NL": "56",
		"NAME": "56",
		"POPU": "291200",
		"AREA": "264.85",
		"Density": "1099.4902775156"
	},
	{
		"GEOZIP2NL": "57",
		"NAME": "57",
		"POPU": "180100",
		"AREA": "499.61",
		"Density": "360.4811753167"
	},
	{
		"GEOZIP2NL": "58",
		"NAME": "58",
		"POPU": "87200",
		"AREA": "456.31",
		"Density": "191.0981569547"
	},
	{
		"GEOZIP2NL": "59",
		"NAME": "59",
		"POPU": "177600",
		"AREA": "445.33",
		"Density": "398.8053802798"
	},
	{
		"GEOZIP2NL": "60",
		"NAME": "60",
		"POPU": "212000",
		"AREA": "675.71",
		"Density": "313.7440618017"
	},
	{
		"GEOZIP2NL": "61",
		"NAME": "61",
		"POPU": "176000",
		"AREA": "243.47",
		"Density": "722.8816691995"
	},
	{
		"GEOZIP2NL": "62",
		"NAME": "62",
		"POPU": "187300",
		"AREA": "256.39",
		"Density": "730.5277116892"
	},
	{
		"GEOZIP2NL": "63",
		"NAME": "63",
		"POPU": "107100",
		"AREA": "158.68",
		"Density": "674.9432820771"
	},
	{
		"GEOZIP2NL": "64",
		"NAME": "64",
		"POPU": "194800",
		"AREA": "114.78",
		"Density": "1697.1597839345"
	},
	{
		"GEOZIP2NL": "65",
		"NAME": "65",
		"POPU": "217500",
		"AREA": "233.20",
		"Density": "932.6758147513"
	},
	{
		"GEOZIP2NL": "66",
		"NAME": "66",
		"POPU": "159800",
		"AREA": "475.03",
		"Density": "336.399806328"
	},
	{
		"GEOZIP2NL": "67",
		"NAME": "67",
		"POPU": "129700",
		"AREA": "309.19",
		"Density": "419.483165691"
	},
	{
		"GEOZIP2NL": "68",
		"NAME": "68",
		"POPU": "201000",
		"AREA": "212.21",
		"Density": "947.1749681919"
	},
	{
		"GEOZIP2NL": "69",
		"NAME": "69",
		"POPU": "155000",
		"AREA": "384.56",
		"Density": "403.0580403578"
	},
	{
		"GEOZIP2NL": "70",
		"NAME": "70",
		"POPU": "127200",
		"AREA": "384.75",
		"Density": "330.604288499"
	},
	{
		"GEOZIP2NL": "71",
		"NAME": "71",
		"POPU": "96900",
		"AREA": "467.73",
		"Density": "207.1708036688"
	},
	{
		"GEOZIP2NL": "72",
		"NAME": "72",
		"POPU": "111100",
		"AREA": "540.95",
		"Density": "205.3794250855"
	},
	{
		"GEOZIP2NL": "73",
		"NAME": "73",
		"POPU": "171300",
		"AREA": "445.23",
		"Density": "384.7449632774"
	},
	{
		"GEOZIP2NL": "74",
		"NAME": "74",
		"POPU": "215300",
		"AREA": "713.40",
		"Density": "301.7942248388"
	},
	{
		"GEOZIP2NL": "75",
		"NAME": "75",
		"POPU": "296400",
		"AREA": "442.19",
		"Density": "670.3000972433"
	},
	{
		"GEOZIP2NL": "76",
		"NAME": "76",
		"POPU": "172300",
		"AREA": "551.97",
		"Density": "312.1546460858"
	},
	{
		"GEOZIP2NL": "77",
		"NAME": "77",
		"POPU": "109700",
		"AREA": "738.35",
		"Density": "148.5745242771"
	},
	{
		"GEOZIP2NL": "78",
		"NAME": "78",
		"POPU": "116900",
		"AREA": "561.39",
		"Density": "208.2331356098"
	},
	{
		"GEOZIP2NL": "79",
		"NAME": "79",
		"POPU": "130200",
		"AREA": "787.33",
		"Density": "165.369032045"
	},
	{
		"GEOZIP2NL": "80",
		"NAME": "80",
		"POPU": "190700",
		"AREA": "476.18",
		"Density": "400.4788105338"
	},
	{
		"GEOZIP2NL": "81",
		"NAME": "81",
		"POPU": "108400",
		"AREA": "572.09",
		"Density": "189.4806761174"
	},
	{
		"GEOZIP2NL": "82",
		"NAME": "82",
		"POPU": "142800",
		"AREA": "790.28",
		"Density": "180.695449714"
	},
	{
		"GEOZIP2NL": "83",
		"NAME": "83",
		"POPU": "102100",
		"AREA": "925.35",
		"Density": "110.3366293835"
	},
	{
		"GEOZIP2NL": "84",
		"NAME": "84",
		"POPU": "103500",
		"AREA": "713.34",
		"Density": "145.092101943"
	},
	{
		"GEOZIP2NL": "85",
		"NAME": "85",
		"POPU": "43100",
		"AREA": "399.89",
		"Density": "107.7796394008"
	},
	{
		"GEOZIP2NL": "86",
		"NAME": "86",
		"POPU": "42400",
		"AREA": "187.37",
		"Density": "226.2902278913"
	},
	{
		"GEOZIP2NL": "87",
		"NAME": "87",
		"POPU": "34000",
		"AREA": "300.05",
		"Density": "113.3144475921"
	},
	{
		"GEOZIP2NL": "88",
		"NAME": "88",
		"POPU": "46300",
		"AREA": "330.40",
		"Density": "140.1331719128"
	},
	{
		"GEOZIP2NL": "89",
		"NAME": "89",
		"POPU": "82800",
		"AREA": "45.20",
		"Density": "1831.8584070797"
	},
	{
		"GEOZIP2NL": "90",
		"NAME": "90",
		"POPU": "61400",
		"AREA": "450.54",
		"Density": "136.2809073556"
	},
	{
		"GEOZIP2NL": "91",
		"NAME": "91",
		"POPU": "43300",
		"AREA": "379.76",
		"Density": "114.0193806615"
	},
	{
		"GEOZIP2NL": "92",
		"NAME": "92",
		"POPU": "136100",
		"AREA": "584.67",
		"Density": "232.7808849436"
	},
	{
		"GEOZIP2NL": "93",
		"NAME": "93",
		"POPU": "55100",
		"AREA": "306.61",
		"Density": "179.7071197939"
	},
	{
		"GEOZIP2NL": "94",
		"NAME": "94",
		"POPU": "121300",
		"AREA": "763.64",
		"Density": "158.8444816929"
	},
	{
		"GEOZIP2NL": "95",
		"NAME": "95",
		"POPU": "67400",
		"AREA": "492.98",
		"Density": "136.7195423749"
	},
	{
		"GEOZIP2NL": "96",
		"NAME": "96",
		"POPU": "150600",
		"AREA": "758.31",
		"Density": "198.5995173478"
	},
	{
		"GEOZIP2NL": "97",
		"NAME": "97",
		"POPU": "216800",
		"AREA": "257.30",
		"Density": "842.5961912165"
	},
	{
		"GEOZIP2NL": "98",
		"NAME": "98",
		"POPU": "34900",
		"AREA": "307.00",
		"Density": "113.680781759"
	},
	{
		"GEOZIP2NL": "99",
		"NAME": "99",
		"POPU": "95000",
		"AREA": "755.92",
		"Density": "125.6746745687"
	}
]